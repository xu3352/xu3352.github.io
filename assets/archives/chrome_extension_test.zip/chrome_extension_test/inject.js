// web page js
function page_var_save() {
    console.log("================ page_var_save...");
    if ("undefined" == typeof g_config) return;

    var data = g_config;
    var j = JSON.stringify(data);
    console.log(j);
    var d = document.createElement('div');
    d.id = "var-shadow";
    d.style = "display:none;";
    d.appendChild(document.createTextNode(j));
    document.body.appendChild(d);
}


// 加个延时, 方便看结果
setTimeout(function() {
    page_var_save();
}, 3000);

