// DOM 注入JS ===================================
function loadJs(url) {
    var s = document.createElement('script');
    s.src = url;
    document.body.appendChild(s);
}
loadJs('//ajax.aspnetcdn.com/ajax/jQuery/jquery-3.4.1.min.js');

function loadLocalJs(files) {
    for (var i = 0; i < files.length; i++) {
        var s = document.createElement('script');
        s.src = chrome.extension.getURL(files[i]);
        document.body.appendChild(s);
    }
}
loadLocalJs(['inject.js']);

// something else =============================================
function send_message(data) {
    var param = {type: 'message', data: data};
    chrome.runtime.sendMessage(param, function(response) {
        console.log("send_message log:" + response);
    });
}

function close_tab() {
    chrome.runtime.sendMessage({type: "close_tab"});
}

function open_tab(url) {
    chrome.runtime.sendMessage({type: "open_tab_url", data: url});
}

function change_tab(url) {
    chrome.runtime.sendMessage({type: "change_tab_url", data: url});
}

function send_detail_log() {
    var param = {type: 'send_detail_log', data: {}};
    chrome.runtime.sendMessage(param, function(response) {
        console.log("send_detail_log log:" + JSON.stringify(response));
    });
}

// 本地取值
function get_local_datas() {
    chrome.storage.local.get(["g_status", "g_cnt"], function(result) {
        var g_status = result["g_status"] || 0;
        var g_cnt = result["g_cnt"] || 0;
        console.log("load_local_datas: " + g_status + ", " + g_cnt);
        // do something...
    });
}

// 本地存值
function set_local_data(key, value) {
    chrome.storage.local.set({key: value});
}

function front_test(msg) {
    console.log('front_test...: ' + msg);
}
