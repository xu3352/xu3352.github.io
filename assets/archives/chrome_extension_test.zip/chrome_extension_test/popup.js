
function injectFrontScript(code) {
    chrome.tabs.executeScript(null, {code:code});
}

$(document).ready(function(){
    $("#test").click(function(){
        var msg = $("#msg").val();
        injectFrontScript("front_test('"+msg+"')");
    });
});
