// message listener ======================================================
chrome.runtime.onMessage.addListener(function(request, sender, sendResponse) {
    // console.log('data:' + JSON.stringify(request.data));
    if (request.type == "message") {
        var data = request.data;
        // do something...
        sendResponse('bg got it...');
    } else if (request.type == "close_tab") {
        chrome.tabs.remove(sender.tab.id);
    } else if (request.type == "open_tab_url") {
        var url = request.url;
        chrome.tabs.create({url: url, active: false});
    } else if (request.type == "change_tab_url") {
        var tabId = sender.tab.id;
        var url = request.url;
        chrome.tabs.update(tabId, {url: url});
    } else if (request.type == "send_detail_log") {
        // jquery post request
        var param = request.data;
        $.post('http://host/path/detail_log', param, function(data){
            sendResponse(data);
        });
    }
    // 等待 sendResponse 把数据返回
    return true;
});
